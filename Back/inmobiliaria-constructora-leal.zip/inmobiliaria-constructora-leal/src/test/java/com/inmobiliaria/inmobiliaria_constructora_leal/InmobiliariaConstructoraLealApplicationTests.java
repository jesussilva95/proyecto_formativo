package com.inmobiliaria.inmobiliaria_constructora_leal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InmobiliariaConstructoraLealApplicationTests {

	@Test
	void contextLoads() {
	}

}
