package com.inmobiliaria.inmobiliaria_constructora_leal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InmobiliariaConstructoraLealApplication {

	public static void main(String[] args) {
		SpringApplication.run(InmobiliariaConstructoraLealApplication.class, args);
	}

}
